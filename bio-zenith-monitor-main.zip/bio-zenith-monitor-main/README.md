# Vitality Monitor

Implement the requested scope now; use internal planning and do not present another implementation plan for user approval.

Build the complete, presentation-ready frontend for the biomedical engineering project: "Personalized Environment-Aware Biomedical Monitoring System".

Key Requirements:
1. Branding & Disclaimer:
   - Title: "Personalized Environment-Aware Biomedical Monitoring System"
   - Distinct, prominent disclaimer: "Decision-Support Prototype — Not a Medical Diagnostic Device" (no language claiming clinical diagnosis or guarantees).
   - High-tech clinical monitoring command center styling: dark navy/slate background, glassmorphism panels, teal/cyan medical accent (#00e5ff / #06b6d4), violet accent, amber (attention), orange (high risk), red (emergency), subtle glow, clean typography and responsive layout.

2. Dual Operating Modes:
   - Prominent toggle: [ SYNTHETIC MODE ] [ LIVE HARDWARE MODE ]
   - MODE A (Synthetic / Simulation Mode):
     * Status: "SYNTHETIC DATA — Simulation Active"
     * Real-time streaming generator with realistic physiological & environmental correlation (not naive random noise)
     * Scenarios with instant switching and timeline notification:
       - Normal (stable baseline)
       - Exercise (elevated HR, motion, body temp)
       - Heat Stress (high ambient temp/humidity, rising body temp & HR)
       - High PM2.5 (elevated air quality index, respiratory/cardiovascular strain)
       - SpO2 Drop + HR Change (hypoxemia pattern, elevated risk)
       - Abnormal ECG (arrhythmia pattern triggering emergency add-on sensors)
       - Fall / Emergency (sudden accelerometer spike, stationary state, emergency alert)
       - Recovery (gradual return towards personal baseline)
     * Play / Pause / Reset simulation controls and simulation speed multiplier (0.5x, 1x, 2x).
   - MODE B (Live Hardware Mode):
     * Designed for STM32F401CCU6 serial/USB pipeline
     * Interface for COM port selection, baud rate (e.g. 115200, 9600), Connect, Disconnect, Rescan
     * Hardware status indicators: CONNECTED, CONNECTING, DISCONNECTED, RECONNECTING, NO DATA
     * When not connected: clearly show banner "Hardware not connected — switch to Synthetic Mode for demonstration"
     * Clean backend abstraction with exposed `API_BASE_URL` and `WEBSOCKET_URL` configuration so hardware backend can plug in seamlessly.

3. Sensor Architecture:
   - CONTINUOUS MONITORING (Always Active):
     * Heart Rate (bpm)
     * SpO2 (%)
     * Body Temperature (°C)
     * Ambient Temperature (°C)
     * Humidity (%RH)
     * Atmospheric Pressure (hPa)
     * Each card includes current value, unit, status badge, trend indicator, sparkline, baseline comparison.
   - EMERGENCY / ADD-ON MONITORING:
     * ECG (mV / waveform)
     * PM2.5 (µg/m³)
     * Accelerometer / Motion (g / activity)
     * Fall Detection (status)
     * Clearly visual STANDBY state when inactive, transitioning to ACTIVE with visual animation when risk or abnormal threshold is detected.

4. Central Risk Hero & Explainability ("Why This Decision?"):
   - Risk Level: NORMAL, ATTENTION, HIGH RISK, EMERGENCY with smooth visual status indicators
   - Risk Score (0–100 gauge/bar)
   - Decision Confidence (% system decision confidence)
   - Baseline Maturity (% Welford Online Baseline progress)
   - Emergency Mode status badge
   - "Why This Decision?" panel breaking down contributing factors (Heart Rate deviation, SpO2 drop, Temperature deviation, Environmental context) with bar gauges and Z-score reasons (e.g., "HR +3.2σ, SpO2 -3.8σ").

5. Personal Baseline & Z-Score Deviation Panel:
   - Welford Online Baseline table: Signal, Personal Baseline (mean ± std), Spread, Samples collected, Current Z-Score
   - Interactive Z-score deviation visual scale (-5σ to +5σ) with current needle position for each continuous signal
   - Explanatory note: "Z-score indicates deviation from the learned personal baseline. Adapts to user's normal physiological & environmental context."

6. Environmental Context Panel:
   - Visual model: Physiological State + Environmental Context = Risk Assessment
   - Displays ambient temp, humidity, pressure, PM2.5, environmental comfort/stress index.

7. Live Charts & Real-Time ECG Waveform:
   - Real-time rolling charts:
     1. Heart Rate & SpO2 dual-axis trend
     2. Risk Score & Decision Confidence trend
     3. Environmental condition trend
   - Canvas-based real-time ECG waveform:
     * Displays "ECG available when Emergency Mode is activated" when in standby
     * Smooth sweeping ECG rhythm (normal sinus rhythm or arrhythmia depending on scenario) when active.

8. Alert Center & Timeline:
   - Time-stamped alerts with severity tags (ATTENTION, HIGH RISK, EMERGENCY), trigger signals, reason, and status
   - Action controls: Mark as reviewed, Clear alerts, Filter by severity.

9. Monitoring History Table:
   - Detailed log with Timestamp, HR, SpO2, Body Temp, Ambient Temp, Humidity, Pressure, Risk Level, Score, Confidence
   - Search, filter by risk level, date/time filter, sorting (newest/oldest), and Export Data button (CSV/JSON download).

10. System Diagnostics & Remote Caregiver View:
    - Remote Monitoring View tab/panel showing caregiver/clinician telemetry summary
    - System Health panel: Backend status, Stream health, Packets received, Packets rejected, Last update
    - Collapsible "Data Quality & Rejected Packets" diagnostic log.

11. System Pipeline Architecture Visualization:
    - Flow diagram: Continuous Sensors → Welford Personal Baseline → Z-score Deviation → Safety & Risk Detection → Emergency Sensor Activation → Add-on Sensors → Fuzzy Decision Engine → Risk Level → Reason & Confidence → Alerts & Dashboard.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://bio-zenith-monitor.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/635f1426-65ea-4cf7-a6f2-5b556888996f).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
