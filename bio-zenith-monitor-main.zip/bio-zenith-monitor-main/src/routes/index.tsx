import { createFileRoute } from "@tanstack/react-router";
import { MonitoringDashboard } from "@/components/monitoring-dashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Biomedical Monitoring Command Center" },
      { name: "description", content: "Environment-aware physiological monitoring and explainable risk decision-support prototype." },
      { property: "og:title", content: "Personalized Environment-Aware Biomedical Monitoring System" },
      { property: "og:description", content: "Real-time adaptive biomedical monitoring with personal baselines and environmental context." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MonitoringDashboard,
});
